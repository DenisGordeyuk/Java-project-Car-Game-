public class Doge extends Car {

    public void gas(){};
    public void brake(){};


}
