public interface CarInterface {


    public void brake();





}
