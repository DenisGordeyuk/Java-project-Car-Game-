public class Car {

    void drive() {
        System.out.print("=== 8=8 ===== 8=8=====8=8 ");


    }

    void stop() {
        System.out.println(" ==== 8=8 ==== 8=8 == 8=8 = 8=8 ");
    }

    void ParkingFine() {

    }


    void gas(int speedUp) {
        System.out.println(" === 8=8 = 8=8 ===8=8 =========");

    }

    void brake() {
        System.out.print("====== 8=8 === 8=8 ==");

    }


}


