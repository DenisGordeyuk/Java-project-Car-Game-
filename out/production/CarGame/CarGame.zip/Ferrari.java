public class Ferrari extends Car implements CarInterface {
    protected final String NAME = "Ferrari X";
    protected final int maxSpeed = 180;

    public void brake() {
    }

    public void brakingDistances() {
    }

    public void pickingUpSpeed() {
    }

    private String status;

    public String getStatus() {
        return status;
    }

}
