import java.util.Scanner;

public class test {
    public static void main(String[] args) {

        System.out.println("Штраф " + Math.random());
        System.out.println("не штрафы " + Math.random());

    }



    }




